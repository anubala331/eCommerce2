
# Marks 95/100
## General Remarks
This is a very good attempt. However, some of the mistakes pointed out in the first assignment have been repeated which is disappointing (lack of authentication, no session management, no error handling).
## Proper use of VSTS/Git: 20/20%
Contributions by all group members on git
## Correct and complete MongoDB implementation: 20/20%
1. Good work with purchase history.
## Correct and complete NodeJS API endpoints 25/30%
1. All endpoint CRUD methods implemented. 
2. Basic error handling is missing (what if a new user with existing email address is added? What if required fields are missing?).
3. No endpoint implemented for user authentication. This is a key requirement that you will have to address for your final application to work.
4. As mentioned in assignment 1, adequate session handling was not done to protect endpoints that could be possibly exposed to unauthorized users.
## Full suite of Postman tests: 30/30%
Your postman export had URL values from assignment 1 and did not function as expected directly from the export. However, I could see that all the enpoints were captured as required. 