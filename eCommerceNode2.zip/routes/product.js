const express = require("express");
var router = express.Router();

router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

const db = require("./db.js");
ObjectID = require('mongodb').ObjectId; 
db.init();

var indexModule = require("./index.js");
const app = indexModule.app;

//this is for default page
app.get("/", function (req, res) {
  res.send("This is the default page");
});

//this is for getting all product
app.get("/product", async function (req, res) {
  try {
    let products = await db.find("product", {});
    res.json(products);
  } catch (e) {
    print(e);
  }
  });
//this is for product with id
app.get("/product/:id", async function (req, res) {
  try {
    let products = await db.find("product", {_id: ObjectID(req.params.id)});
    res.json(products);
  } catch (e) {
    res.send(e);
  }
});
//this is for porduct insertion
app.post("/product", async function (req, res) {
  try {
    console.log(req.body);
    await db.insertOne("product", req.body);
  } catch (e) {
    print(e);
  }
  res.send("Inserted");
});
//this is for product updation with id
app.put("/product/:id", async function (req, res) {
  try {
    await db.updateOne("product", { _id: ObjectID(req.params.id) }, req.body);
  } catch (e) {
    print(e);
  }
  res.send("Updated");
});
//this is for delete with id
app.delete("/product/:id", async function (req, res) {
  try { 
    await db.deleteOne("product", { _id: ObjectID(req.params.id)});
    res.send("Deleted");
  } catch (e) {
    print(e);
  }
});

module.exports = router;
