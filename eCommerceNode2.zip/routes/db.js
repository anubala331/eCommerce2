const MongoClient = require('mongodb').MongoClient;
const url = 'mongodb://localhost:27017';
const dbName = 'eCommercee';

let client;
let db;
const obj = require('mongodb').ObjectId;

module.exports.init = async () => {
    client = new MongoClient(url);
    try {
        await client.connect();
        console.log('connected to mongoDB');

        db = client.db(dbName);
    }
    catch (err){
        console.log(err.stack)
    }
}

module.exports.find = async (collection, object) => {
    return await db.collection(collection).find(object).toArray();
}
module.exports.insertOne = async (collection, object) => {
    return await db.collection(collection).insertOne(object);
}
module.exports.updateOne = async (collection, original, change) => {
    return await db.collection(collection).updateOne(original, { $set: change});
}
module.exports.deleteOne = async (collection, object) => {
    return await db.collection(collection).deleteOne(object);
}
