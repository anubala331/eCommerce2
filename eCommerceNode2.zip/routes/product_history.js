const express = require("express");
var router = express.Router();

router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

const db = require("./db.js");
ObjectID = require('mongodb').ObjectId; 
db.init();

var indexModule = require("./index.js");
const app = indexModule.app;

//this is for default page
app.get("/", function (req, res) {
  res.send("This is the default page");
});

//this is for getting all product
app.get("/product_history", async function (req, res) {
  try {
    let products = await db.find("product_history", {});
    res.json(products);
  } catch (e) {
    print(e);
  }
  });
//this is for product with id
app.get("/product_history/:userid", async function (req, res) {
  try {
    let products = await db.find("product_history", {userid: req.params.userid});
    res.json(products);
  } catch (e) {
    res.send(e);
  }
});
//this is for porduct insertion
app.post("/product_history", async function (req, res) {
  try {
    console.log(req.body);
    await db.insertOne("product_history", req.body);
  } catch (e) {
    print(e);
  }
  res.send("Inserted");
});

module.exports = router;
