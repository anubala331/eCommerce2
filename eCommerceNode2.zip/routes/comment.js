const express = require("express");
var router = express.Router();

router.get("/", function (req, res, next) {
  res.render("index", { title: "Express" });
});

const db = require("./db.js");
ObjectID = require("mongodb").ObjectId;
db.init();

var indexModule = require("./index.js");
const app = indexModule.app;
//this is for default page
app.get("/", function (req, res) {
  res.send("This is the default page");
});

//get comments details
app.get("/comment", async function (req, res) {
  try {
    let comments = await db.find("comment",{});

    res.json(comments);
  } catch (e) {
    res.send(e);
  }
});

// get all comments by userid
app.get("/comment/:productid", async function (req, res) {
  try {
    let comments = await db.find("comment", {
      productid: req.params.productid,
    });
    res.json(comments);
  } catch (e) {
    print(e);
  }
});

//Add comment
app.post("/comment", async function (req, res) {
  try {
    console.log(req.body);
    await db.insertOne("comment", req.body);
  } catch (e) {
    print(e);
  }
  res.send({ message: "Comment Added" });
});

//update comment with comment id
app.put("/comment/:id", async function (req, res) {
  try {
    console.log(req.body);
    await db.updateOne("comment", { _id: ObjectID(req.params.id) }, req.body);
  } catch (e) {
    print(e);
  }
  res.send({ message: "Comment updated" });
});

//Delete comment with comment id
app.delete("/comment/:id", async function (req, res) {
  try {
    await db.deleteMany("comment", { _id: ObjectID(req.params.id) });
    res.send("Deleted");
  } catch (e) {
    print(e);
  }
  res.send({ message: "Comment deleted" });
});

module.exports = router;
