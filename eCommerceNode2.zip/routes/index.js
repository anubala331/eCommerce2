var express = require('express');
var router = express.Router();

router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

var app = express();
app.use(express.json());
app.use(express.static("public"));
app.listen(3000);
module.exports = {router, app};
